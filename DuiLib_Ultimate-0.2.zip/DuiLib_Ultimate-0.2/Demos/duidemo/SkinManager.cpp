#include "stdafx.h"
#include "SkinManager.h"

CSkinManager CSkinManager::m_SkinManager;