#include "stdafx.h"
#include "ShortCutUI.h"
#include "LabelEx.h"
#include "GameItemUI.h"
#include "ControlEx.h"
//////////////////////////////////////////////////////////////////////////
//
IMPLEMENT_DUICONTROL(CShortCutUI)
	IMPLEMENT_DUICONTROL(CLabelIconUI)
	IMPLEMENT_DUICONTROL(CLabelMutilineUI)
	IMPLEMENT_DUICONTROL(CGameItemUI)
	IMPLEMENT_DUICONTROL(CGameListUI)
